create database h02;
use h02;
create table student_info(student_number int, student_name varchar(20), branch varchar(20), contact_number int, birth_date date, joining_date date, adress varchar(30), email_id varchar(20) );
alter table student_info
modify student_number varchar(20) primary key;
alter table student_info
drop primary key;
alter table student_info
modify student_number varchar(20) primary key;
alter table student_info
modify contact_number int unique key;
alter table student_info
modify email_id varchar(20) unique key;

create table subject_info(subject_code varchar(20) primary key, subject_name varchar(20) unique key, weightage int);

create table marks_scored(student_number varchar(10), subject_code varchar(20),
semister_number int, sem_marks int );
foreign key (student_number) references student_info(student_number);
alter table marks_scored add 
foreign key(subject_code) references subject_info(subject_code);

create table final_result(student_number varchar(20),sem_cgpa float, scholarship_eligibility bit, foreign key(student_number) references student_info(student_number));
 
 create database h03;
 use h03;
 create table student_info(registration_number varchar(20), Student_name varchar(30), branch varchar(20), contact varchar(20), Date_of_birth date, date_of_joining date, address varchar(250), email_id varchar(250));
create table subjects_info (subject_code varchar(10), subject_name varchar(30), weightage int);
create table student_marks (registration_number varchar(20),foreign key(registration_number) references student_info(registration_number), subject_code varchar(10), semester int, marks int);