select si.student_name, si.registration_number, sr.gpa from student_info as si inner join student_result as sr on si.registration_number = sr.registration_number
order by gpa desc;



select * from student_info order by student_name;



select * from student_info order by year(current_date())-year(date_of_birth);


select si.registration_number, si.student_name, sr.semester, sr.gpa from student_info as si
inner join student_result as sr on sr.registration_number = si.registration_number order by sr.gpa desc;



select registration_number, gpa from student_result order by is_eligible_scholarship desc;


select si.registration_number, si.student_name, sr.semester, max(sr.gpa) from student_info as si inner join
student_result as sr on si.registration_number = sr.registration_number
group by sr.semester;



select si.registration_number, si.student_name, sr.semester, min(sr.gpa) from student_info as si inner join
student_result as sr on si.registration_number = sr.registration_number
group by sr.semester;